import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Centralized type scale. 'Manrope' for display/headline (premium,
/// geometric, calm) and 'Inter' for body (highly legible at small sizes).
class AppTypography {
  AppTypography._();

  static TextStyle _manrope(double size, FontWeight w, {double? height, double? letterSpacing}) =>
      GoogleFonts.manrope(fontSize: size, fontWeight: w, height: height, letterSpacing: letterSpacing);

  static TextStyle _inter(double size, FontWeight w, {double? height, double? letterSpacing}) =>
      GoogleFonts.inter(fontSize: size, fontWeight: w, height: height, letterSpacing: letterSpacing);

  static TextStyle displayLarge = _manrope(34, FontWeight.w800, height: 1.15, letterSpacing: -0.5);
  static TextStyle displayMedium = _manrope(28, FontWeight.w800, height: 1.2, letterSpacing: -0.4);
  static TextStyle headlineLarge = _manrope(24, FontWeight.w700, height: 1.25);
  static TextStyle headlineMedium = _manrope(20, FontWeight.w700, height: 1.3);
  static TextStyle titleLarge = _manrope(18, FontWeight.w700, height: 1.3);
  static TextStyle titleMedium = _manrope(16, FontWeight.w700, height: 1.35);

  static TextStyle bodyLarge = _inter(16, FontWeight.w500, height: 1.4);
  static TextStyle bodyMedium = _inter(14, FontWeight.w500, height: 1.4);
  static TextStyle bodySmall = _inter(12.5, FontWeight.w500, height: 1.35);

  static TextStyle labelLarge = _inter(14, FontWeight.w700, letterSpacing: 0.1);
  static TextStyle labelMedium = _inter(12.5, FontWeight.w700, letterSpacing: 0.2);
  static TextStyle labelSmall = _inter(11, FontWeight.w700, letterSpacing: 0.3);

  static TextStyle numeric = _manrope(30, FontWeight.w800, height: 1.0, letterSpacing: -0.5);
}
