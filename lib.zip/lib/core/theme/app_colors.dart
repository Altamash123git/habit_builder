import 'package:flutter/material.dart';

/// Cadence brand palette — calm indigo/violet with a warm coral streak
/// accent and a cool teal focus accent. Distinct from generic finance-app
/// greens on purpose: this is a wellbeing/productivity brand, not a money app.
class AppColors {
  AppColors._();

  // Brand
  static const Color primary = Color(0xFF6C63FF); // violet-indigo
  static const Color primaryDark = Color(0xFF5A52E0);
  static const Color primaryLight = Color(0xFF9C96FF);

  static const Color secondary = Color(0xFF14B8A6); // teal — focus/deep work
  static const Color secondaryDark = Color(0xFF0F9488);

  static const Color streak = Color(0xFFFF7A59); // coral flame
  static const Color streakGlow = Color(0xFFFFB199);

  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF5A623);
  static const Color error = Color(0xFFEF4444);

  // Light theme neutrals
  static const Color lightBg = Color(0xFFF6F6FB);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightBorder = Color(0xFFE9E9F3);
  static const Color lightTextPrimary = Color(0xFF191A23);
  static const Color lightTextSecondary = Color(0xFF6E7080);

  // Dark theme neutrals
  static const Color darkBg = Color(0xFF0F0F1B);
  static const Color darkSurface = Color(0xFF16172A);
  static const Color darkCard = Color(0xFF1C1D33);
  static const Color darkBorder = Color(0xFF2A2B45);
  static const Color darkTextPrimary = Color(0xFFF5F5FA);
  static const Color darkTextSecondary = Color(0xFFA6A7C4);

  // AMOLED neutrals
  static const Color amoledBg = Color(0xFF000000);
  static const Color amoledSurface = Color(0xFF000000);
  static const Color amoledCard = Color(0xFF0B0B0F);
  static const Color amoledBorder = Color(0xFF1C1C22);

  // Category accents (routine/habit tags)
  static const List<Color> categoryAccents = [
    Color(0xFF6C63FF), // morning
    Color(0xFF14B8A6), // focus
    Color(0xFFFF7A59), // fitness
    Color(0xFFF5A623), // self-care
    Color(0xFF3B82F6), // work
    Color(0xFFEC4899), // evening
  ];
}
