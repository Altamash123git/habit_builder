import 'package:flutter/material.dart';
import 'app_colors.dart';

/// Spacing scale — use these instead of magic numbers everywhere.
class AppSpacing {
  AppSpacing._();
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 20;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 40;

  static const EdgeInsets screenPadding = EdgeInsets.symmetric(horizontal: 20);
  static const EdgeInsets cardPadding = EdgeInsets.all(18);
}

/// Corner radius scale — soft, premium, consistent rounding.
class AppRadius {
  AppRadius._();
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
  static const double pill = 999;

  static BorderRadius get card => BorderRadius.circular(lg);
  static BorderRadius get button => BorderRadius.circular(pill);
  static BorderRadius get sheet => const BorderRadius.vertical(top: Radius.circular(28));
  static BorderRadius get chip => BorderRadius.circular(pill);
}

/// Motion durations & curves — used across the app for a consistent feel.
class AppDuration {
  AppDuration._();
  static const Duration fast = Duration(milliseconds: 160);
  static const Duration base = Duration(milliseconds: 260);
  static const Duration slow = Duration(milliseconds: 420);
  static const Duration celebrate = Duration(milliseconds: 900);
  static const Curve curve = Curves.easeOutCubic;
  static const Curve bounce = Curves.easeOutBack;
}

/// Soft, low-opacity shadows — never harsh, matches the calm brand ethos.
class AppShadows {
  AppShadows._();

  static List<BoxShadow> card(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return [
      BoxShadow(
        color: (isDark ? Colors.black : const Color(0xFF1B1B3A)).withOpacity(isDark ? 0.35 : 0.06),
        blurRadius: 24,
        offset: const Offset(0, 10),
      ),
    ];
  }

  static List<BoxShadow> glow(Color color, {double opacity = 0.35}) => [
        BoxShadow(color: color.withOpacity(opacity), blurRadius: 28, spreadRadius: -4, offset: const Offset(0, 10)),
      ];
}

/// Signature brand gradients used across hero cards, buttons and rings.
class AppGradients {
  AppGradients._();

  static const LinearGradient primary = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.primary, Color(0xFF9C63FF)],
  );

  static const LinearGradient streak = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.streak, Color(0xFFFFB24C)],
  );

  static const LinearGradient focus = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.secondary, Color(0xFF34D3C9)],
  );

  static const LinearGradient premium = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF2D2A6E), Color(0xFF6C63FF), Color(0xFFFF7A59)],
  );
}
