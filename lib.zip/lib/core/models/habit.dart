import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import '../utils/date_utils.dart';

enum HabitFrequency { daily, weekly }

class Habit {
  final String id;
  String title;
  IconData icon;
  Color color;
  HabitFrequency frequency;
  int weeklyTarget; // used when frequency == weekly
  bool archived;

  /// Optional free-text note — why this habit matters, how to do it, etc.
  String? notes;

  /// Optional short motivational line shown on the detail screen and used
  /// as the body of the daily reminder notification, if set.
  String? motivation;

  /// Optional target — "build this habit in N days" (e.g. 21/30/66/custom).
  /// Null means an open-ended, ongoing habit with no deadline.
  int? goalDays;

  /// When the habit was created / the goal clock started.
  DateTime startDate;

  /// If true, a best-effort "you haven't checked this off yet" notification
  /// is scheduled for the evening (see NotificationService). Local
  /// notifications can't inspect app state at fire time, so this always
  /// fires — it's a safety-net nudge, not a guaranteed-accurate miss detector.
  bool missedReminderEnabled;

  String? reminderTime; // 'HH:mm', 24h, local time — null means no daily reminder

  /// Dates (yyyy-MM-dd keys) on which the habit was checked off.
  Set<String> completedDates;

  Habit({
    required this.id,
    required this.title,
    this.icon = Icons.check_circle_rounded,
    this.color = const Color(0xFF6C63FF),
    this.frequency = HabitFrequency.daily,
    this.weeklyTarget = 3,
    this.archived = false,
    this.notes,
    this.motivation,
    this.goalDays,
    DateTime? startDate,
    this.missedReminderEnabled = false,
    this.reminderTime,
    Set<String>? completedDates,
  })  : startDate = startDate ?? AppDate.dateOnly(DateTime.now()),
        completedDates = completedDates ?? <String>{};

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'icon': icon.codePoint,
    'color': color.value,
    'frequency': frequency.name,
    'weeklyTarget': weeklyTarget,
    'archived': archived,
    'notes': notes,
    'motivation': motivation,
    'goalDays': goalDays,
    'startDate': startDate.toIso8601String(),
    'missedReminderEnabled': missedReminderEnabled,
    'reminderTime': reminderTime,
    'completedDates': completedDates.toList(),
  };

  factory Habit.fromJson(Map<String, dynamic> j) => Habit(
    id: j['id'] as String,
    title: j['title'] as String,
    icon: IconData(j['icon'] as int? ?? Icons.check_circle_rounded.codePoint, fontFamily: 'MaterialIcons'),
    color: Color(j['color'] as int? ?? 0xFF6C63FF),
    frequency: HabitFrequency.values.firstWhere((f) => f.name == j['frequency'], orElse: () => HabitFrequency.daily),
    weeklyTarget: j['weeklyTarget'] as int? ?? 3,
    archived: j['archived'] as bool? ?? false,
    notes: j['notes'] as String?,
    motivation: j['motivation'] as String?,
    goalDays: j['goalDays'] as int?,
    startDate: j['startDate'] != null ? DateTime.parse(j['startDate'] as String) : AppDate.dateOnly(DateTime.now()),
    missedReminderEnabled: j['missedReminderEnabled'] as bool? ?? false,
    reminderTime: j['reminderTime'] as String?,
    completedDates: ((j['completedDates'] as List?) ?? const []).map((e) => e as String).toSet(),
  );
}

/// Goal / progress math kept alongside the model so every screen computes
/// it the same way.
extension HabitProgressX on Habit {
  /// 1-indexed day count since the habit was created (today counts as day 1).
  int get daysSinceStart => AppDate.dateOnly(DateTime.now()).difference(startDate).inDays + 1;

  bool get hasGoal => goalDays != null && goalDays! > 0;

  /// Progress toward the day-count goal, based on total check-ins so far.
  /// Null when the habit has no deadline.
  double? get goalProgress {
    if (!hasGoal) return null;
    return (completedDates.length / goalDays!).clamp(0.0, 1.0);
  }

  bool get goalReached => hasGoal && completedDates.length >= goalDays!;

  int? get daysRemainingInGoal {
    if (!hasGoal) return null;
    return (goalDays! - completedDates.length).clamp(0, goalDays!);
  }

  /// Share of days since start that were completed — a simple, forgiving
  /// consistency metric shown on the detail screen.
  double get consistencyRate {
    final days = daysSinceStart.clamp(1, 1 << 30);
    return (completedDates.length / days).clamp(0.0, 1.0);
  }

  /// How many days since start were missed (past days, not completed).
  int get missedDaysCount => (daysSinceStart - completedDates.length).clamp(0, 1 << 30);
}