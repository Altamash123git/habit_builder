import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/theme/app_tokens.dart';

class StreakFlame extends StatelessWidget {
  final int streak;
  final double iconSize;
  const StreakFlame({super.key, required this.streak, this.iconSize = 16});

  @override
  Widget build(BuildContext context) {
    final active = streak > 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        gradient: active ? AppGradients.streak : null,
        color: active ? null : Theme.of(context).cardColor,
        borderRadius: AppRadius.chip,
        border: active ? null : Border.all(color: context.colors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.local_fire_department_rounded, size: iconSize, color: active ? Colors.white : context.colors.textSecondary),
          const SizedBox(width: 4),
          Text(
            '$streak',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 12.5,
              color: active ? Colors.white : context.colors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
