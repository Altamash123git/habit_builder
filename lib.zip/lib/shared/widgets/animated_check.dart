import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_tokens.dart';

/// A satisfying tappable check circle — scales & fills with a gradient
/// when completed. This is the core "reward" micro-interaction of the app.
class AnimatedCheck extends StatelessWidget {
  final bool checked;
  final VoidCallback onTap;
  final double size;
  final Color color;

  const AnimatedCheck({super.key, required this.checked, required this.onTap, this.size = 28, this.color = AppColors.primary});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: AppDuration.base,
        curve: AppDuration.bounce,
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: checked ? color : Colors.transparent,
          border: Border.all(color: checked ? color : Theme.of(context).dividerColor, width: 2),
          boxShadow: [BoxShadow(color: color.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4))] ,
        ),
        child: AnimatedSwitcher(
          duration: AppDuration.fast,
          transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
          child: checked
              ? Icon(Icons.check_rounded, key: const ValueKey('checked'), size: size * 0.62, color: Colors.white)
              : const SizedBox.shrink(key: ValueKey('unchecked')),
        ),
      ),
    );
  }
}
