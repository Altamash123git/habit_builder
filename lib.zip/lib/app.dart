import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/state/app_state.dart';
import 'core/theme/app_theme.dart';
import 'features/onboarding/onboarding_screen.dart';
import 'features/shell/root_shell.dart';

class CadenceApp extends StatelessWidget {
  const CadenceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final mode = context.watch<AppState>().themeMode;
    final theme = switch (mode) {
      AppThemeMode.light => AppTheme.light(),
      AppThemeMode.dark => AppTheme.dark(),
      AppThemeMode.amoled => AppTheme.amoled(),
    };

    return MaterialApp(
      title: 'Cadence',
      debugShowCheckedModeBanner: false,
      theme: theme,
      home: context.watch<AppState>().onboarded ? const RootShell() : const OnboardingScreen(),
    );
  }
}
