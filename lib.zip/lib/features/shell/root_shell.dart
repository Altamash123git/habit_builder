import 'package:flutter/material.dart';
import '../../shared/widgets/app_bottom_nav.dart';
import '../today/today_screen.dart';
import '../routines/routines_screen.dart';
import '../habits/habits_screen.dart';
import '../focus/focus_screen.dart';
import '../progress/progress_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  final _screens = const [
    TodayScreen(),
    RoutinesScreen(),
    HabitsScreen(),
    FocusScreen(),
    ProgressScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: AppBottomNav(index: _index, onChanged: (i) => setState(() => _index = i)),
    );
  }
}
