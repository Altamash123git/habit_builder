import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../shared/widgets/misc_widgets.dart';
import 'routine_detail_screen.dart';
import 'routine_editor_screen.dart';
import 'widgets/routine_card.dart';

class RoutinesScreen extends StatelessWidget {
  const RoutinesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final routines = state.routines;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton(
          backgroundColor: AppColors.primary,
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RoutineEditorScreen())),
          child: const Icon(Icons.add_rounded, color: Colors.white),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Routines', style: Theme.of(context).textTheme.displayMedium),
                if (!state.isPremium) Text('${routines.length}/$maxRoutinesFree free', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            const SizedBox(height: 20),
            if (routines.isEmpty)
              EmptyState(
                icon: Icons.checklist_rounded,
                title: 'Start your first routine',
                subtitle: 'Pick a template or build your own morning, work, or self-care routine in seconds.',
                actionLabel: 'New routine',
                onAction: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RoutineEditorScreen())),
              )
            else
              for (final r in routines)
                RoutineCard(routine: r, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => RoutineDetailScreen(routineId: r.id)))),
          ],
        ),
      ),
    );
  }
}
