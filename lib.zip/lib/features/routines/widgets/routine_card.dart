import 'package:flutter/material.dart';
import '../../../core/models/routine.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/app_card.dart';

class RoutineCard extends StatelessWidget {
  final Routine routine;
  final VoidCallback onTap;
  const RoutineCard({super.key, required this.routine, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = routine.category.color;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: AppCard(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(routine.category.icon, size: 13, color: color),
                      const SizedBox(width: 5),
                      Text(routine.category.label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: color)),
                    ],
                  ),
                ),
                const Spacer(),
                if (routine.isDoneToday)
                  Icon(Icons.check_circle_rounded, color: color, size: 20)
                else
                  Text('${routine.completedCount}/${routine.tasks.length}', style: Theme.of(context).textTheme.labelMedium),
              ],
            ),
            const SizedBox(height: 12),
            Text(routine.title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: routine.progress),
                duration: const Duration(milliseconds: 600),
                builder: (context, value, _) => LinearProgressIndicator(
                  value: value,
                  minHeight: 7,
                  backgroundColor: context.colors.border,
                  valueColor: AlwaysStoppedAnimation(color),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
