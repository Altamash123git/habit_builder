import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/theme/app_tokens.dart';
import '../../shared/widgets/app_card.dart';
import '../../shared/widgets/misc_widgets.dart';
import 'widgets/premium_sheet.dart';
import 'widgets/theme_selector.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
        children: [
          if (!state.isPremium)
            AppCard(
              onTap: () => showPremiumSheet(context),
              gradient: AppGradients.premium,
              child: const Row(
                children: [
                  Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 26),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Go Premium', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                        SizedBox(height: 3),
                        Text('Remove ads & unlock everything', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded, color: Colors.white),
                ],
              ),
            )
          else
            const AppCard(
              gradient: AppGradients.premium,
              child: Row(
                children: [
                  Icon(Icons.verified_rounded, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  Text('Premium active — thank you!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          const SizedBox(height: 26),
          SectionHeader(title: 'Notifications'),
          AppCard(
            child: Row(
              children: [
                Icon(Icons.notifications_active_rounded, size: 20, color: context.colors.textPrimary),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Reminders', style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: context.colors.textPrimary)),
                      const SizedBox(height: 2),
                      Text('Routine & habit reminders, plus a daily evening check-in', style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
                Switch(value: state.remindersEnabled, onChanged: (v) => context.read<AppState>().setRemindersEnabled(v)),
              ],
            ),
          ),
          const SizedBox(height: 26),
          SectionHeader(title: 'Appearance'),
          const ThemeSelector(),
          const SizedBox(height: 26),
          SectionHeader(title: 'Data'),
          AppCard(
            child: Column(
              children: [
                _SettingsRow(
                  icon: Icons.download_rounded,
                  label: 'Export data (JSON)',
                  onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wire this to a file-export package, e.g. share_plus.'))),
                ),
                const Divider(height: 24),
                _SettingsRow(
                  icon: Icons.delete_forever_rounded,
                  label: 'Reset all data',
                  color: AppColors.error,
                  onTap: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Reset everything?'),
                        content: const Text('This permanently deletes all routines, habits and focus history from this device.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Reset')),
                        ],
                      ),
                    );
                    if (confirmed == true) {
                      await context.read<AppState>().resetAllData();
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          SectionHeader(title: 'About'),
          AppCard(
            child: Column(
              children: [
                _SettingsRow(icon: Icons.privacy_tip_rounded, label: 'Privacy — everything stays on this device', onTap: null),
                const Divider(height: 24),
                _SettingsRow(icon: Icons.info_outline_rounded, label: 'Cadence v1.0.0', onTap: null),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? color;
  final VoidCallback? onTap;

  const _SettingsRow({required this.icon, required this.label, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = color ?? context.colors.textPrimary;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Row(
        children: [
          Icon(icon, size: 20, color: c),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: c))),
          if (onTap != null) Icon(Icons.chevron_right_rounded, color: context.colors.textSecondary),
        ],
      ),
    );
  }
}
