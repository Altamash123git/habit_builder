import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/focus_session.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../../shared/widgets/app_card.dart';
import '../../shared/widgets/misc_widgets.dart';
import 'widgets/stat_card.dart';
import 'widgets/weekly_bar_chart.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final days = AppDate.lastDays(7);
    final weekValues = days.map((d) => state.completionRateOn(d)).toList();

    final unlocked = kAchievements.where((a) => a.isUnlocked(state.bestOverallStreak, state.totalCompletions, state.totalFocusMinutes)).toList();
    final locked = kAchievements.where((a) => !unlocked.contains(a)).toList();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
        children: [
          Text('Progress', style: Theme.of(context).textTheme.displayMedium),
          const SizedBox(height: 18),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: [
              StatCard(icon: Icons.local_fire_department_rounded, color: AppColors.streak, value: '${state.currentOverallStreak}', label: 'Current streak'),
              StatCard(icon: Icons.emoji_events_rounded, color: AppColors.warning, value: '${state.bestOverallStreak}', label: 'Best streak'),
              StatCard(icon: Icons.timer_rounded, color: AppColors.secondary, value: '${state.totalFocusMinutes}m', label: 'Focus time'),
              StatCard(icon: Icons.task_alt_rounded, color: AppColors.primary, value: '${state.totalCompletions}', label: 'Completions'),
            ],
          ),
          const SizedBox(height: 24),
          SectionHeader(title: 'This week'),
          AppCard(child: WeeklyBarChart(values: weekValues)),
          const SizedBox(height: 24),
          SectionHeader(title: 'Achievements'),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final a in unlocked) _AchievementChip(achievement: a, unlocked: true),
              for (final a in locked) _AchievementChip(achievement: a, unlocked: false),
            ],
          ),
        ],
      ),
    );
  }
}

class _AchievementChip extends StatelessWidget {
  final Achievement achievement;
  final bool unlocked;
  const _AchievementChip({required this.achievement, required this.unlocked});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: unlocked ? 1 : 0.4,
      child: Container(
        width: 104,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: context.colors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: unlocked ? AppColors.primary.withOpacity(0.4) : context.colors.border),
        ),
        child: Column(
          children: [
            Text(achievement.icon, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 8),
            Text(achievement.title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelMedium),
          ],
        ),
      ),
    );
  }
}
