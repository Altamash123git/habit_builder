import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';

class TimerDial extends StatelessWidget {
  final double progress; // 0..1 remaining
  final String timeLabel;
  final String modeLabel;
  final Color color;
  final bool running;

  const TimerDial({super.key, required this.progress, required this.timeLabel, required this.modeLabel, required this.color, required this.running});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 280,
      height: 280,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: const Size(280, 280),
            painter: _DialPainter(progress: progress, trackColor: context.colors.border, color: color),
          ),
          AnimatedScale(
            scale: running ? 1.0 : 0.96,
            duration: const Duration(milliseconds: 400),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(modeLabel.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: 1.2)),
                const SizedBox(height: 8),
                Text(timeLabel, style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 52)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DialPainter extends CustomPainter {
  final double progress;
  final Color trackColor;
  final Color color;

  _DialPainter({required this.progress, required this.trackColor, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final track = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, track);

    final arc = Paint()
      ..shader = SweepGradient(colors: [color.withOpacity(0.5), color], startAngle: -math.pi / 2, endAngle: -math.pi / 2 + 2 * math.pi)
          .createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -math.pi / 2, 2 * math.pi * progress, false, arc);
  }

  @override
  bool shouldRepaint(covariant _DialPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.color != color;
}
