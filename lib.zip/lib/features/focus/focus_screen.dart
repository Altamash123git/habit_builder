import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/misc_widgets.dart';
import 'widgets/timer_dial.dart';

enum _FocusMode { work, shortBreak, longBreak }

extension on _FocusMode {
  String get label => switch (this) {
        _FocusMode.work => 'Focus',
        _FocusMode.shortBreak => 'Short break',
        _FocusMode.longBreak => 'Long break',
      };
  int get minutes => switch (this) {
        _FocusMode.work => 25,
        _FocusMode.shortBreak => 5,
        _FocusMode.longBreak => 15,
      };
  Color get color => switch (this) {
        _FocusMode.work => AppColors.secondary,
        _FocusMode.shortBreak => AppColors.success,
        _FocusMode.longBreak => AppColors.primary,
      };
}

class FocusScreen extends StatefulWidget {
  const FocusScreen({super.key});

  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> {
  _FocusMode _mode = _FocusMode.work;
  late int _remainingSeconds = _mode.minutes * 60;
  Timer? _timer;
  bool _running = false;
  int _completedWorkSessions = 0;

  int get _totalSeconds => _mode.minutes * 60;

  void _toggle() {
    if (_running) {
      _pause();
    } else {
      _start();
    }
  }

  void _start() {
    setState(() => _running = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_remainingSeconds <= 1) {
        _complete();
      } else {
        setState(() => _remainingSeconds--);
      }
    });
  }

  void _pause() {
    _timer?.cancel();
    setState(() => _running = false);
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _running = false;
      _remainingSeconds = _mode.minutes * 60;
    });
  }

  void _complete() {
    _timer?.cancel();
    final state = context.read<AppState>();
    if (_mode == _FocusMode.work) {
      state.logFocusSession(_mode.minutes, label: 'Focus session');
      _completedWorkSessions++;
    } else if (state.remindersEnabled) {
      state.notifications.showFocusSessionComplete(modeLabel: _mode.label, minutes: 0);
    }
    final next = _mode == _FocusMode.work
        ? (_completedWorkSessions % 4 == 0 ? _FocusMode.longBreak : _FocusMode.shortBreak)
        : _FocusMode.work;
    setState(() {
      _running = false;
      _mode = next;
      _remainingSeconds = next.minutes * 60;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_mode == _FocusMode.work ? 'Break\'s over — back to focus!' : 'Nice work — take a break.')));
    }
  }

  void _switchMode(_FocusMode m) {
    _timer?.cancel();
    setState(() {
      _mode = m;
      _running = false;
      _remainingSeconds = m.minutes * 60;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _format(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final todayMinutes = state.focusMinutesOn(DateTime.now());
    final progress = 1 - (_remainingSeconds / _totalSeconds);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
        children: [
          Text('Focus', style: Theme.of(context).textTheme.displayMedium),
          const SizedBox(height: 4),
          Text('$todayMinutes min focused today · ad-free & distraction-free', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 8),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: TimerDial(
                progress: progress,
                timeLabel: _format(_remainingSeconds),
                modeLabel: _mode.label,
                color: _mode.color,
                running: _running,
              ),
            ),
          ),
          Center(
            child: Wrap(
              spacing: 8,
              children: [
                for (final m in _FocusMode.values)
                  ChoiceChip(
                    label: Text(m.label),
                    selected: _mode == m,
                    onSelected: (_) => _switchMode(m),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _reset,
                  child: const Padding(padding: EdgeInsets.symmetric(vertical: 4), child: Text('Reset')),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: GradientButton(
                  label: _running ? 'Pause' : (_remainingSeconds == _totalSeconds ? 'Start' : 'Resume'),
                  icon: _running ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  gradient: LinearGradient(colors: [_mode.color, _mode.color.withOpacity(0.7)]),
                  onTap: _toggle,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
