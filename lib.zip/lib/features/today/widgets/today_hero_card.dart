import 'package:flutter/material.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/progress_ring.dart';

class TodayHeroCard extends StatelessWidget {
  final int doneTasks;
  final int totalTasks;
  final int doneHabits;
  final int totalHabits;

  const TodayHeroCard({super.key, required this.doneTasks, required this.totalTasks, required this.doneHabits, required this.totalHabits});

  @override
  Widget build(BuildContext context) {
    final totalDone = doneTasks + doneHabits;
    final totalAll = totalTasks + totalHabits;
    final progress = totalAll == 0 ? 0.0 : totalDone / totalAll;

    return AppCard(
      gradient: AppGradients.primary,
      showShadow: true,
      child: Row(
        children: [
          ProgressRing(
            progress: progress,
            size: 78,
            strokeWidth: 8,
            gradientColors: const [Colors.white, Colors.white70],
            center: Text('${(progress * 100).round()}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          const SizedBox(width: AppSpacing.lg),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  totalAll == 0 ? 'Add a routine or habit to begin' : (progress >= 1 ? 'Day complete — amazing work' : 'Today\'s progress'),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17),
                ),
                const SizedBox(height: 6),
                Text(
                  '$totalDone of $totalAll tasks & habits done',
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w500, fontSize: 13.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
