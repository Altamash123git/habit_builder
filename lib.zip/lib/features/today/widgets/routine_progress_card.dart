import 'package:flutter/material.dart';
import '../../../core/models/routine.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/progress_ring.dart';

class RoutineProgressCard extends StatelessWidget {
  final Routine routine;
  final VoidCallback onTap;
  const RoutineProgressCard({super.key, required this.routine, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = routine.category.color;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(14)),
              child: Icon(routine.category.icon, color: color, size: 22),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(routine.title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 3),
                  Text('${routine.completedCount}/${routine.tasks.length} tasks', style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
            ProgressRing(
              progress: routine.progress,
              size: 42,
              strokeWidth: 5,
              gradientColors: [color, color.withOpacity(0.6)],
              center: routine.isDoneToday ? Icon(Icons.check_rounded, size: 18, color: color) : null,
            ),
          ],
        ),
      ),
    );
  }
}
