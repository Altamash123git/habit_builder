import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/models/habit.dart';
import '../../../core/state/app_state.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/animated_check.dart';

class HabitQuickRow extends StatelessWidget {
  final Habit habit;
  const HabitQuickRow({super.key, required this.habit});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final done = state.isHabitDoneToday(habit);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        showShadow: false,
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: habit.color.withOpacity(0.14), borderRadius: BorderRadius.circular(12)),
              child: Icon(habit.icon, color: habit.color, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                habit.title,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: context.colors.textPrimary,
                      decoration: done ? TextDecoration.lineThrough : null,
                    ),
              ),
            ),
            AnimatedCheck(checked: done, onTap: () => context.read<AppState>().toggleHabitToday(habit.id), color: habit.color),
          ],
        ),
      ),
    );
  }
}
