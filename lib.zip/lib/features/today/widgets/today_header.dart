import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/streak_flame.dart';
import '../../settings/settings_screen.dart';

class TodayHeader extends StatelessWidget {
  final String name;
  final int streak;
  const TodayHeader({super.key, required this.name, required this.streak});

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$_greeting,', style: Theme.of(context).textTheme.bodyLarge),
              Text(name, style: Theme.of(context).textTheme.displayMedium),
            ],
          ),
        ),
        StreakFlame(streak: streak, iconSize: 18),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: context.colors.card, shape: BoxShape.circle, border: Border.all(color: context.colors.border)),
            child: Icon(Icons.settings_rounded, color: context.colors.textPrimary, size: 20),
          ),
        ),
      ],
    );
  }
}
