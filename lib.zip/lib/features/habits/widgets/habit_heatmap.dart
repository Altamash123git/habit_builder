import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/date_utils.dart';

/// Simple GitHub-style contribution heatmap for a single habit,
/// showing the last [weeks] weeks (7 * weeks days).
class HabitHeatmap extends StatelessWidget {
  final Set<String> completedDates;
  final Color color;
  final int weeks;

  const HabitHeatmap({super.key, required this.completedDates, required this.color, this.weeks = 12});

  @override
  Widget build(BuildContext context) {
    final days = AppDate.lastDays(weeks * 7);
    // group into columns of 7 (weeks), oldest first
    final columns = <List<DateTime>>[];
    for (int i = 0; i < days.length; i += 7) {
      columns.add(days.sublist(i, (i + 7).clamp(0, days.length)));
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      reverse: true,
      child: Row(
        children: [
          for (final col in columns)
            Padding(
              padding: const EdgeInsets.only(right: 4),
              child: Column(
                children: [
                  for (final d in col)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Container(
                        width: 13,
                        height: 13,
                        decoration: BoxDecoration(
                          color: completedDates.contains(AppDate.key(d)) ? color : context.colors.border,
                          borderRadius: BorderRadius.circular(3.5),
                        ),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
