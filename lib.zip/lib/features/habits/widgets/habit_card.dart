import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/models/habit.dart';
import '../../../core/state/app_state.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/date_utils.dart';
import '../../../shared/widgets/animated_check.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/streak_flame.dart';

class HabitCard extends StatelessWidget {
  final Habit habit;
  final VoidCallback onTap;
  const HabitCard({super.key, required this.habit, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final done = state.isHabitDoneToday(habit);
    final streak = AppDate.currentStreak(habit.completedDates);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(color: habit.color.withOpacity(0.14), borderRadius: BorderRadius.circular(14)),
              child: Icon(habit.icon, color: habit.color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(habit.title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 5),
                  StreakFlame(streak: streak, iconSize: 13),
                ],
              ),
            ),
            AnimatedCheck(checked: done, onTap: () => context.read<AppState>().toggleHabitToday(habit.id), color: habit.color, size: 32),
          ],
        ),
      ),
    );
  }
}
