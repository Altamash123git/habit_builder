import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/models/habit.dart';
import '../../core/services/templates.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/date_utils.dart';
import '../../shared/widgets/misc_widgets.dart';

const _uuid = Uuid();

/// Create or edit a habit. This is the "real life habit builder": title,
/// visual identity, an optional note on *why* it matters, an optional
/// motivational line used in reminders, an optional day-count goal
/// ("build this in 21 days"), and reminder settings — including a
/// best-effort "you might miss this" evening nudge.
class HabitEditorScreen extends StatefulWidget {
  final Habit? existing;
  const HabitEditorScreen({super.key, this.existing});

  @override
  State<HabitEditorScreen> createState() => _HabitEditorScreenState();
}

class _HabitEditorScreenState extends State<HabitEditorScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _notesController;
  late final TextEditingController _motivationController;
  late final TextEditingController _customGoalController;

  IconData _icon = kHabitIconChoices.first;
  Color _color = AppColors.categoryAccents.first;
  int? _goalDays; // null = no deadline
  bool _customGoalSelected = false;
  TimeOfDay? _reminderTime;
  bool _missedReminderEnabled = false;

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final h = widget.existing;
    _titleController = TextEditingController(text: h?.title ?? '');
    _notesController = TextEditingController(text: h?.notes ?? '');
    _motivationController = TextEditingController(text: h?.motivation ?? '');
    _icon = h?.icon ?? kHabitIconChoices.first;
    _color = h?.color ?? AppColors.categoryAccents.first;
    _goalDays = h?.goalDays;
    _customGoalSelected = h != null && h.goalDays != null && !kHabitGoalPresets.any((p) => p.days == h.goalDays);
    _customGoalController = TextEditingController(text: _customGoalSelected ? '${h!.goalDays}' : '');
    _reminderTime = AppDate.parseTimeOfDay(h?.reminderTime);
    _missedReminderEnabled = h?.missedReminderEnabled ?? false;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _notesController.dispose();
    _motivationController.dispose();
    _customGoalController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Give your habit a name.')));
      return;
    }

    int? goalDays = _goalDays;
    if (_customGoalSelected) {
      goalDays = int.tryParse(_customGoalController.text.trim());
      if (goalDays == null || goalDays <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid number of days for your custom goal.')));
        return;
      }
    }

    final state = context.read<AppState>();
    final reminderTimeStr = _reminderTime == null ? null : AppDate.formatTimeOfDay(_reminderTime!);

    if (_isEditing) {
      final updated = widget.existing!;
      updated.title = title;
      updated.icon = _icon;
      updated.color = _color;
      updated.notes = _notesController.text.trim().isEmpty ? null : _notesController.text.trim();
      updated.motivation = _motivationController.text.trim().isEmpty ? null : _motivationController.text.trim();
      updated.goalDays = goalDays;
      updated.reminderTime = reminderTimeStr;
      updated.missedReminderEnabled = _missedReminderEnabled;
      await state.updateHabit(updated);
      if (mounted) Navigator.of(context).pop();
    } else {
      final ok = await state.addHabit(Habit(
        id: _uuid.v4(),
        title: title,
        icon: _icon,
        color: _color,
        notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
        motivation: _motivationController.text.trim().isEmpty ? null : _motivationController.text.trim(),
        goalDays: goalDays,
        reminderTime: reminderTimeStr,
        missedReminderEnabled: _missedReminderEnabled,
      ));
      if (mounted) {
        if (ok) {
          Navigator.of(context).pop();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Free plan limit reached — upgrade to Premium for unlimited habits.')));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'Edit habit' : 'New habit')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
        children: [
          Text('Habit name', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          TextField(controller: _titleController, autofocus: !_isEditing, decoration: const InputDecoration(hintText: 'e.g. Drink water')),
          const SizedBox(height: 22),

          Text('Icon', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final i in kHabitIconChoices)
                GestureDetector(
                  onTap: () => setState(() => _icon = i),
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: _icon == i ? _color.withOpacity(0.18) : context.colors.card,
                      shape: BoxShape.circle,
                      border: Border.all(color: _icon == i ? _color : context.colors.border),
                    ),
                    child: Icon(i, size: 19, color: _icon == i ? _color : context.colors.textSecondary),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 22),

          Text('Color', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            children: [
              for (final c in AppColors.categoryAccents)
                GestureDetector(
                  onTap: () => setState(() => _color = c),
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: _color == c ? Border.all(color: context.colors.textPrimary, width: 2) : null),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 22),

          Text('Why does this matter to you? (optional)', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          TextField(
            controller: _motivationController,
            maxLines: 2,
            maxLength: 120,
            decoration: const InputDecoration(hintText: 'e.g. "Future me deserves the energy this gives."'),
          ),
          const SizedBox(height: 6),
          Text('Shown on the detail screen and used in your reminder notification.', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 18),

          Text('Notes (optional)', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          TextField(
            controller: _notesController,
            maxLines: 4,
            decoration: const InputDecoration(hintText: 'How exactly will you do this? Any triggers, cues or plans.'),
          ),
          const SizedBox(height: 22),

          Text('Goal — build this habit in…', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final preset in kHabitGoalPresets)
                _GoalChip(
                  label: preset.label,
                  selected: preset.days == -1 ? _customGoalSelected : (!_customGoalSelected && _goalDays == preset.days),
                  color: _color,
                  onTap: () => setState(() {
                    if (preset.days == -1) {
                      _customGoalSelected = true;
                      _goalDays = null;
                    } else {
                      _customGoalSelected = false;
                      _goalDays = preset.days;
                    }
                  }),
                ),
            ],
          ),
          if (_customGoalSelected) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customGoalController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: 'Number of days', suffixText: 'days'),
            ),
          ],
          const SizedBox(height: 22),

          Text('Daily reminder', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () async {
                    final picked = await showTimePicker(context: context, initialTime: _reminderTime ?? const TimeOfDay(hour: 9, minute: 0));
                    if (picked != null) setState(() => _reminderTime = picked);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                    decoration: BoxDecoration(color: context.colors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: context.colors.border)),
                    child: Row(
                      children: [
                        Icon(Icons.notifications_active_rounded, size: 18, color: _reminderTime != null ? _color : context.colors.textSecondary),
                        const SizedBox(width: 10),
                        Text(
                          _reminderTime == null ? 'No reminder' : 'Remind me at ${_reminderTime!.format(context)}',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: context.colors.textPrimary),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (_reminderTime != null)
                IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => _reminderTime = null)),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: context.colors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: context.colors.border)),
            child: Row(
              children: [
                Icon(Icons.local_fire_department_rounded, size: 18, color: context.colors.textSecondary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Remind me if I miss it', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: context.colors.textPrimary)),
                      Text('Best-effort nudge around 9 PM if the day is at risk', style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
                Switch(value: _missedReminderEnabled, onChanged: (v) => setState(() => _missedReminderEnabled = v)),
              ],
            ),
          ),

          const SizedBox(height: 30),
          GradientButton(label: _isEditing ? 'Save changes' : 'Create habit', onTap: _save),
        ],
      ),
    );
  }
}

class _GoalChip extends StatelessWidget {
  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  const _GoalChip({required this.label, required this.selected, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: AppDuration.fast,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.16) : context.colors.card,
          border: Border.all(color: selected ? color : context.colors.border, width: selected ? 1.6 : 1),
          borderRadius: AppRadius.chip,
        ),
        child: Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: selected ? color : context.colors.textPrimary)),
      ),
    );
  }
}