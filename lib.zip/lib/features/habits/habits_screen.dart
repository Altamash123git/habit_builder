import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/models/habit.dart';
import '../../core/state/app_state.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/date_utils.dart';
import '../../shared/widgets/misc_widgets.dart';
import 'habit_create_edit.dart';
import 'habit_detail_screen.dart';
import 'widgets/habit_card.dart';

const _uuid = Uuid();

const _iconChoices = [
  Icons.water_drop_rounded,
  Icons.menu_book_rounded,
  Icons.directions_run_rounded,
  Icons.self_improvement_rounded,
  Icons.bedtime_rounded,
  Icons.no_food_rounded,
  Icons.edit_note_rounded,
  Icons.spa_rounded,
  Icons.fitness_center_rounded,
  Icons.emoji_food_beverage_rounded,
];

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});

  void _openEditor(BuildContext context) {
    final state = context.read<AppState>();
    if (state.habitLimitReached) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Free plan limit reached — upgrade to Premium for unlimited habits.')));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HabitEditorScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final habits = state.habits;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton(
          heroTag: null,
          backgroundColor: AppColors.primary,
          onPressed: () => _openEditor(context),
          child: const Icon(Icons.add_rounded),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Habits', style: Theme.of(context).textTheme.displayMedium),
                if (!state.isPremium) Text('${habits.length}/$maxHabitsFree free', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            const SizedBox(height: 20),
            if (habits.isEmpty)
              EmptyState(
                icon: Icons.local_fire_department_rounded,
                title: 'Build your first habit',
                subtitle: 'Small daily actions compound. Add a habit, set a goal, and start your streak today.',
                actionLabel: 'New habit',
                onAction: () => _openEditor(context),
              )
            else
              for (final h in habits)
                HabitCard(habit: h, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => HabitDetailScreen(habitId: h.id)))),
          ],
        ),
      ),
    );
  }
}
